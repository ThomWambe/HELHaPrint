<?php

namespace AppBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\ResetType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;


class FilesType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
        
                ->add('File',FileType::class,array(
                    'label'=>' ',
                    'required'=>True,
                ))
                ->add('Title',TextType::class,array(
                    'label'=>'If you want to Rename your file',
                    'required'=> false,
                ))
                ->add('FinalDate',DateType::class,array(
                    'required'=> true,
                    'label'=>'Due date',
                    'format'=>'dd-MM-yyyy',
                    'years'=>range(date('Y'),date('Y')+6)
                ))
                ->add('Upload',SubmitType::class)
                ->add('Reset',ResetType::class)
                ;
    }/**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'AppBundle\Entity\Files'
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'appbundle_files';
    }


}
