<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Files
 *
 * @ORM\Table(name="files")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\FilesRepository")
 */
class Files
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="Title", type="string", length=255)
     */
    private $title;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="CreationDate", type="date")
     */
    private $creationDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="FinalDate", type="date")
     */
    private $finalDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="PrintedDate", type="date", nullable=true)
     */
    private $printedDate;

    /**
     * @var int
     *
     * @ORM\Column(name="Weight", type="integer")
     */
    private $weight;

    /**
     * @var int
     *
     * @ORM\Column(name="Time", type="integer")
     */
    private $time;

    /**
     * @var int
     *
     * @ORM\Column(name="Owner", type="integer")
     */
    private $owner;

    /**
     * @var string
     *
     * @ORM\Column(name="File", type="string", length=255)
     */
    private $file;
    
    /**
     * @var bool
     *
     * @ORM\Column(name="Done", type="boolean")
     */
    private $done;

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return Files
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set creationDate
     *
     * @param \DateTime $creationDate
     *
     * @return Files
     */
    public function setCreationDate($creationDate)
    {
        $this->creationDate = $creationDate;

        return $this;
    }

    /**
     * Get creationDate
     *
     * @return \DateTime
     */
    public function getCreationDate()
    {
        return $this->creationDate;
    }

    /**
     * Set finalDate
     *
     * @param \DateTime $finalDate
     *
     * @return Files
     */
    public function setFinalDate($finalDate)
    {
        $this->finalDate = $finalDate;

        return $this;
    }

    /**
     * Get finalDate
     *
     * @return \DateTime
     */
    public function getFinalDate()
    {
        return $this->finalDate;
    }

    /**
     * Set printedDate
     *
     * @param \DateTime $printedDate
     *
     * @return Files
     */
    public function setPrintedDate($printedDate)
    {
        $this->printedDate = $printedDate;

        return $this;
    }

    /**
     * Get printedDate
     *
     * @return \DateTime
     */
    public function getPrintedDate()
    {
        return $this->printedDate;
    }

    /**
     * Set weight
     *
     * @param integer $weight
     *
     * @return Files
     */
    public function setWeight($weight)
    {
        $this->weight = $weight;

        return $this;
    }

    /**
     * Get weight
     *
     * @return int
     */
    public function getWeight()
    {
        return $this->weight;
    }

    /**
     * Set time
     *
     * @param integer $time
     *
     * @return Files
     */
    public function setTime($time)
    {
        $this->time = $time;

        return $this;
    }

    /**
     * Get time
     *
     * @return int
     */
    public function getTime()
    {
        return $this->time;
    }

    /**
     * Set owner
     *
     * @param int $owner
     *
     * @return Files
     */
    public function setOwner($owner)
    {
        $this->owner = $owner;

        return $this;
    }

    /**
     * Get owner
     *
     * @return int
     */
    public function getOwner()
    {
        return $this->owner;
    }

    /**
     * Set file
     *
     * @param string $file
     *
     * @return Files
     */
    public function setFile($file)
    {
        $this->file = $file;

        return $this;
    }

    /**
     * Get file
     *
     * @return string
     */
    public function getFile()
    {
        return $this->file;
    }

     /**
     * Set done
     *
     * @param bool $done
     *
     * @return Files
     */
    public function setDone($done)
    {
        $this->done = $done;

        return $this;
    }

    /**
     * Get done
     *
     * @return bool
     */
    public function getDone()
    {
        return $this->done;
    }
}

