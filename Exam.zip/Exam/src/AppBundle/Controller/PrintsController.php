<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Files;
use AppBundle\Form\FilesType;
use Symfony\Component\HttpFoundation\Request;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class PrintsController extends Controller 
{

    /**
     * 
     * @Route("/AddPrints/", name="AddPrints")
     */
    public function addPrintsFormAction()
    {
        $files = new Files();
        $formFiles =$this->createForm(FilesType::class,$files,array(
            'action'=>$this->generateUrl('SuccesAddFiles')
        ));
        return $this->render('@App/AddPrints.html.twig', [
            'formFiles'=>$formFiles->createView()
        ]);
    }

    /**
     * 
     * @Route("/MyPrints/", name="MyPrints")
     */
    public function myPrintsAction()
    {
        $doctrine=$this->getDoctrine();;
        $repositoryFiles =$doctrine->getRepository('AppBundle:Files'); 

        $OwnerLog = $this->getUser()->getId();

        $showProgress = array_merge($repositoryFiles->findBy(['owner'=> $OwnerLog , 'done'=>0],['finalDate'=>'ASC']));
        $showDone = array_merge($repositoryFiles->findBy(['owner'=> $OwnerLog , 'done'=>1],['finalDate'=>'ASC']));

        $today = new \DateTime("now");

        return $this->render('@App/MyPrints.html.twig', [
            'showProgress'=> $showProgress,
            'showDone'=> $showDone,
            'today'=>$today
        ]);
    }

    /**
     * @Route("/Admin/", name="Admin")
     */
    public function AdminAction(){

        $doctrine=$this->getDoctrine();
        $repositoryFiles =$doctrine->getRepository('AppBundle:Files'); 
    
        $repositoryUser =$doctrine->getRepository('AppBundle:User'); 

        $showProgress = array_merge($repositoryFiles->findBy(['done'=>0],['finalDate'=>'ASC']));
        $showDone = array_merge($repositoryFiles->findBy(['done'=>1],['finalDate'=>'ASC']));

        $show = array_merge($showProgress,$showDone);
        $owners = $repositoryUser->findAll();

        $today = new \DateTime("now");

        return $this->render('@App/Admin.html.twig', [
            'show'=> $show,
            'showProgress'=> $showProgress,
            'showDone'=>$showDone,
            'owners'=> $owners,
            'today'=>$today,
        ]);
    }

    /**
     * @param $id
     * 
     * @Route("/setToDone/{id}", name="SetToDone")
     */
    
    public function setToDoneAction($id)
    {
        $doctrine=$this->getDoctrine();

        $repository =$doctrine->getRepository('AppBundle:Files'); 

        $fich = $repository->findOneBy(['id'=> $id]);

        $fich->setDone(1);
        $fich->setPrintedDate(new \DateTime("now"));

        $em = $this->getDoctrine()->getManager();
        $em->persist($fich);
        $em->flush();    
        ;
        return $this->redirectToRoute('Admin');
    }

    /**
     * @param $id
     * @param $entity
     * 
     * @Route("/setToProceed/{id}", name="SetToProceed")
     */
    
    public function setToProceedAction($id)
    {
        $doctrine=$this->getDoctrine();

        $repository =$doctrine->getRepository('AppBundle:Files'); 

        $fich = $repository->findOneBy(['id'=> $id]);

        $fich->setDone(0);
        $fich->setPrintedDate(null);

        $em = $this->getDoctrine()->getManager();
        $em->persist($fich);
        $em->flush();    
        ;
        return $this->redirectToRoute('Admin');
    }

    /**
     * 
     * @Route("/SuccesAddFiles",name="SuccesAddFiles")
     */
    public function addFilesAction(Request $request)
    {
        $files = new Files();
        $form =$this->createForm(FilesType::class,$files);
        $form->handleRequest($request);

        $upload=$form['File']->getData();
        
        if(($form['Title']->getData())==null){
            $files->setTitle($upload->getClientOriginalName( ));
        }else{
            $files->setTitle($form['Title']->getData().'.'.$upload->getClientOriginalExtension());
        }

        $files->setCreationDate(new \DateTime("now"));

        $files->setWeight(intval($upload->getClientSize()/1000));

        $files->setTime($files->getWeight()*10+rand(0,200));

        $files->setOwner($this->getUser()->getId());

        $files->setDone(0);

        $em = $this->getDoctrine()->getManager();
        $em->persist($files);
        $em->flush();
            
        if($form->IsSubmitted()){
            $extension = $upload->getClientOriginalExtension();
            $newUploadName =$this->getUser()->getUserName().'.'.$files->getTitle().md5(uniqid()).'.' . $extension;
            $upload->move($this->getParameter('upload_files'),$newUploadName);
            $files->setFile($newUploadName);
        }
        
        
        return $this->render('@App/SuccesAddPrints.html.twig', [
            'time' => date("H:i:s",$files->getTime()),
            'title' => $files->getTitle()
            
        ]);
    }
}

