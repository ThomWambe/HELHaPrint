<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;


class DefaultController extends Controller
{
    /**
     * @Route("/", name="Homepage")
     */
    public function IndexAction(){
        return $this->render('@App/Index.html.twig');
    }


    /**
     * @Route("/Error/", name="Error")
     */
    public function ErrorAction(){
        return $this->render('@App/_Error.html');
    }


}
